package com.example.weighttrackerui;

/** Simple model for a weight entry (date + weight string). */
public class WeightEntry {
    private final String date;
    private final String weight;

    public WeightEntry(String date, String weight) {
        this.date = date;
        this.weight = weight;
    }

    public String getDate() {
        return date;
    }

    public String getWeight() {
        return weight;
    }
}
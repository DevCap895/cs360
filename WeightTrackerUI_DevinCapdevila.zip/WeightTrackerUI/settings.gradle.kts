rootProject.name = "WeightTrackerUI"
include(":app")
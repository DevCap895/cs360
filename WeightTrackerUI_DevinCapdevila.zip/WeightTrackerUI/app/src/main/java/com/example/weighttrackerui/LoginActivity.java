package com.example.weighttrackerui;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    private EditText usernameEdit;
    private EditText passwordEdit;
    private Button signInButton;
    private Button createAccountButton;

    private WeightDatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // Initialize UI components
        usernameEdit = findViewById(R.id.et_username);
        passwordEdit = findViewById(R.id.et_password);
        signInButton = findViewById(R.id.btn_sign_in);
        createAccountButton = findViewById(R.id.btn_create_account);

        // Initialize database helper
        dbHelper = new WeightDatabaseHelper(this);

        // Sign-In logic
        signInButton.setOnClickListener(v -> {
            String username = usernameEdit.getText().toString().trim();
            String password = passwordEdit.getText().toString().trim();

            if (validateInputs(username, password)) {
                if (dbHelper.checkUser(username, password)) {
                    Toast.makeText(LoginActivity.this, "Login Successful!", Toast.LENGTH_SHORT).show();
                    navigateToWeightList();
                } else {
                    Toast.makeText(LoginActivity.this, "Invalid username or password!", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // Create Account logic
        createAccountButton.setOnClickListener(v -> {
            String newUsername = usernameEdit.getText().toString().trim();
            String newPassword = passwordEdit.getText().toString().trim();

            if (validateInputs(newUsername, newPassword)) {
                if (dbHelper.addUser(newUsername, newPassword)) {
                    Toast.makeText(LoginActivity.this, "Account created successfully!", Toast.LENGTH_SHORT).show();
                    navigateToWeightList();
                } else {
                    Toast.makeText(LoginActivity.this, "Username already exists!", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private boolean validateInputs(String username, String password) {
        if (TextUtils.isEmpty(username) || TextUtils.isEmpty(password)) {
            Toast.makeText(this, "Both fields are required!", Toast.LENGTH_SHORT).show();
            return false;
        }
        return true;
    }

    private void navigateToWeightList() {
        Intent intent = new Intent(LoginActivity.this, WeightListActivity.class);
        startActivity(intent);
        finish();
    }
}
// Module-level Gradle (Kotlin DSL) - place at <project-root>/app/build.gradle.kts
plugins {
    id("com.android.application")
}

android {
    compileSdk = 33

    defaultConfig {
        // applicationId must match your package in manifest & Java source
        applicationId = "com.example.weighttrackerui"
        minSdk = 21
        targetSdk = 33
        versionCode = 1
        versionName = "1.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    // Optional: explicitly set namespace (AGP supports it)
    namespace = "com.example.weighttrackerui"

    buildTypes {
        getByName("release") {
            isMinifyEnabled = false
            // proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }

    compileOptions {
        // Use Java 11 for compilation (matches AGP 7.4.2 expectations)
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }

    // If you use viewBinding / dataBinding later, enable here
    // buildFeatures {
    //     viewBinding = true
    // }
}

repositories {
    google()
    mavenCentral()
}

dependencies {
    implementation("androidx.appcompat:appcompat:1.6.1")
    implementation("com.google.android.material:material:1.9.0")
    implementation("androidx.constraintlayout:constraintlayout:2.1.4")
    implementation("androidx.recyclerview:recyclerview:1.3.0")
    implementation("androidx.cardview:cardview:1.0.0")

    // Test deps (optional)
    testImplementation("junit:junit:4.13.2")
    androidTestImplementation("androidx.test.ext:junit:1.1.5")
    androidTestImplementation("androidx.test.espresso:espresso-core:3.5.1")
}
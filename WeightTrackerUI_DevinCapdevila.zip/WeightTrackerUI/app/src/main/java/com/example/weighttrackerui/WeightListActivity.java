package com.example.weighttrackerui;

import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;

public class WeightListActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private WeightAdapter adapter;
    private ArrayList<WeightEntry> entries;
    private FloatingActionButton fabAdd;
    private WeightDatabaseHelper dbHelper;
    private TextView headerLabel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weight_list);

        // Setup database helper
        dbHelper = new WeightDatabaseHelper(this);

        // Bind UI elements
        headerLabel = findViewById(R.id.tv_header);
        recyclerView = findViewById(R.id.recycler_grid);
        fabAdd = findViewById(R.id.fab_add);

        entries = new ArrayList<>();
        adapter = new WeightAdapter(entries, this::onDeleteEntry);
        recyclerView.setLayoutManager(new GridLayoutManager(this, 2));
        recyclerView.setAdapter(adapter);

        headerLabel.setText(getString(R.string.grid_header_label));

        fabAdd.setOnClickListener(v -> showAddEntryDialog());

        // Load weight logs
        loadWeightLogs();
    }

    private void loadWeightLogs() {
        entries.clear();
        Cursor cursor = dbHelper.getAllWeightLogs();
        if (cursor.moveToFirst()) {
            do {
                String date = cursor.getString(cursor.getColumnIndex("date"));
                double weight = cursor.getDouble(cursor.getColumnIndex("weight"));
                entries.add(new WeightEntry(date, String.format("%.1f lb", weight)));
            } while (cursor.moveToNext());
        }
        cursor.close();
        adapter.notifyDataSetChanged();
    }

    private void onDeleteEntry(int position) {
        WeightEntry entry = entries.get(position);
        if (dbHelper.deleteWeightLog(entry.getDate())) {
            entries.remove(position);
            adapter.notifyItemRemoved(position);
            Toast.makeText(this, "Entry deleted!", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Failed to delete entry.", Toast.LENGTH_SHORT).show();
        }
    }

    private void showAddEntryDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(R.string.add_entry_title);

        View dialogView = getLayoutInflater().inflate(R.layout.dialog_add_weight, null);
        builder.setView(dialogView);

        builder.setPositiveButton(R.string.add, (dialog, which) -> {
            String date = ((TextView) dialogView.findViewById(R.id.dialog_entry_date)).getText().toString().trim();
            String weightStr = ((TextView) dialogView.findViewById(R.id.dialog_entry_weight)).getText().toString().trim();

            if (!date.isEmpty() && !weightStr.isEmpty()) {
                double weight = Double.parseDouble(weightStr);
                if (dbHelper.addWeightLog(date, weight)) {
                    entries.add(new WeightEntry(date, String.format("%.1f lb", weight)));
                    adapter.notifyItemInserted(entries.size() - 1);
                } else {
                    Toast.makeText(this, "Failed to add entry. Possibly duplicate date.", Toast.LENGTH_SHORT).show();
                }
            }
        });

        builder.setNegativeButton(R.string.cancel, (dialog, which) -> dialog.dismiss());
        builder.create().show();
    }
}
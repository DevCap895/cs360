// Project-level Gradle (Kotlin DSL) - place at <project-root>/build.gradle.kts
buildscript {
    repositories {
        google()
        mavenCentral()
    }
    dependencies {
        // Keep this AGP version to match a Java 11 toolchain (avoids requiring JDK17)
        classpath("com.android.tools.build:gradle:8.13.1")
    }
}

allprojects {
    repositories {
        google()
        mavenCentral()
    }
}
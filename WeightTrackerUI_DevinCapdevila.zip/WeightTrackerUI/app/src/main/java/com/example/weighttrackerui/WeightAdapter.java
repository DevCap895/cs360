package com.example.weighttrackerui;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

/** Minimal RecyclerView adapter for WeightEntry using item_weight_card.xml. */
public class WeightAdapter extends RecyclerView.Adapter<WeightAdapter.VH> {

    public interface DeleteCallback { void onDelete(int position); }

    private final List<WeightEntry> items;
    private final DeleteCallback deleteCallback;

    public WeightAdapter(List<WeightEntry> items, DeleteCallback deleteCallback) {
        this.items = items;
        this.deleteCallback = deleteCallback;
    }

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_weight_card, parent, false);
        return new VH(v);
    }

    @Override
    public void onBindViewHolder(@NonNull VH holder, int position) {
        WeightEntry e = items.get(position);
        holder.date.setText(e.getDate());
        holder.weight.setText(e.getWeight() + " lb");
        holder.delete.setOnClickListener(view -> {
            if (deleteCallback != null) deleteCallback.onDelete(holder.getAdapterPosition());
        });
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    static class VH extends RecyclerView.ViewHolder {
        TextView date;
        TextView weight;
        ImageButton delete;

        VH(@NonNull View itemView) {
            super(itemView);
            date = itemView.findViewById(R.id.entry_date);
            weight = itemView.findViewById(R.id.entry_weight);
            delete = itemView.findViewById(R.id.btn_delete_entry);
        }
    }
}